import json
import os
import time
import logging

# import requests
from botocore.vendored import requests

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

""" --- Helpers to build responses which match the structure of the necessary dialog actions --- """


def get_slots(intent_request):
    logger.debug(intent_request);
    return intent_request['currentIntent']['slots']


# def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
#     return {
#         'sessionAttributes': session_attributes,
#         'dialogAction': {
#             'type': 'ElicitSlot',
#             'intentName': intent_name,
#             'slots': slots,
#             'slotToElicit': slot_to_elicit,
#             'message': message
#         }
#     }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


# def delegate(session_attributes, slots):
#     return {
#         'sessionAttributes': session_attributes,
#         'dialogAction': {
#             'type': 'Delegate',
#             'slots': slots
#         }
#     }

""" --- Functions that control the bot's behavior --- """


def search_mooc(intent_request):
    """
    Performs dialog management and fulfillment for ordering flowers.
    Beyond fulfillment, the implementation of this intent demonstrates the use of the elicitSlot dialog action
    in slot validation and re-prompting.
    """

    logger.debug(intent_request)
    topics = get_slots(intent_request)["Topics"]
    source = intent_request['invocationSource']
    
    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        # Use the elicitSlot dialog action to re-prompt for the first violation detected.
        slots = get_slots(intent_request)

        # elicit_slot(intent_request['sessionAttributes'],
        #             intent_request['currentIntent']['name'])
        
    # url = 'https://www.googleapis.com/customsearch/v1?',
    key = 'AIzaSyADP_zZmL7QcT_VtDETXQ6M4zi_M8yj97o',
    cx = '012893891677016550527:auwhotqscmc',
        # slots

        # Pass the price of the flowers back through session attributes to be used in various prompts defined
        # on the bot model.
        # output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
        # if numberof_passengers is not None:
        #     output_session_attributes['Price'] = (numberof_passengers) * 5  # Elegant pricing model

        # return delegate(output_session_attributes, get_slots(intent_request))
    
    

    # defining a params dict for the parameters to be sent to the API 
    PARAMS={'key':key,
            'cx':cx,
            'q':topics},
    
    # sending get request and saving the response as response object
    logger.debug("Before hitting API")
    response = requests.get('https://www.googleapis.com/customsearch/v1', params = PARAMS)
    logger.debug("After hitting API")
    logger.debug(response.status)
    logger.debug(response);
  
    # # extracting data in json format 
    # data = r.json()
    # print(response.'items')
    # results = response.items
    # print(results)

    # Order the flowers, and rely on the goodbye message of the bot to define the message to the end user.
    # In a real bot, this would likely involve a call to a backend service.
    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': response["items"][0]["link"]} )


""" --- Intents --- """


def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    logger.debug('dispatch userId={}, intentName={}'.format(intent_request['userId'], intent_request['currentIntent']['name']))
    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'SearchMOOC':
        return search_mooc(intent_request)

    raise Exception('Intent with name ' + intent_name + ' not supported')
    
    
""" --- Main handler --- """
    
def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # By default, treat the user request as coming from the America/New_York time zone.
    os.environ['TZ'] = 'America/New_York'
    time.tzset()
    logger.debug('event.bot.name={}'.format(event['bot']['name']))
    logger.debug(event)
    return dispatch(event)
